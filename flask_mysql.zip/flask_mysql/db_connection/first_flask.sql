SELECT * FROM first_flask.friends;

INSERT INTO friends (first_name, last_name, occupation) 
VALUES ('John', 'Smith', 'Engineer'), ('Carson', 'Lee', 'Lawyer');