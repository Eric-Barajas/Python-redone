# for_loop_basics_i_python


## Tasks

- [ ] Create a [Python file](main.py)
- [ ] Basics
- [ ] Multiples of Five
- [ ] Counting, the Dojo Way
- [ ] Whoa. That Sucker's Huge
- [ ] Countdown by Fours
- [ ] Flexible Counter