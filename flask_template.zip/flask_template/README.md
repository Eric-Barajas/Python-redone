- [x] make new directory for the project
- [ ] create a virtual environment 

- [ ] create [server.py](server.py)
- [ ] create a templates directory with my html [files](/templates/index.html)
- [ ] to add styling add [static](/static/css/style.css)
